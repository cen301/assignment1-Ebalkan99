package Operating_Sys;
import java.util.Scanner;
public class Sum_Array {
	
	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		int sum=0;
		int[] arr= new int[10];
		
		System.out.println("Enter "+ arr.length +" number ");
		
		for(int i=0; i<arr.length; i++) {
			arr[i]=input.nextInt();
			sum+=arr[i];
			}

			System.out.println("Sum="+ sum);
}
}