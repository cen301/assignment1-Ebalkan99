#include <stdio.h>
#include <stdlib.h>

void main()
{
char ch;
FILE *fp=fopen("example_input.txt","r");

while(!feof(fp))
	{
	ch=getc(fp);
	printf("\n%c",ch);
}
printf("number of char: %ld\n",ftell(fp));

fclose(fp);
return 0;
}

