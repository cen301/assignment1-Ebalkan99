#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>

#define PHILOSOPHER 5
#define HUNGRY 0
#define EATING 1
#define THINKING 2
#define LEFT (num + 4) % PHILOSOPHER 
#define RIGHT (num + 1) % PHILOSOPHER 

int state[PHILOSOPHER];
int phil[PHILOSOPHER]={0,1,2,3,4};

sem_t mutex;
sem_t P[PHILOSOPHER];

void hungryEating(int num){
	if(state[num]==HUNGRY && state[LEFT]!=EATING && state[RIGHT]!=EATING){
		state[num]=EATING;
		printf("Philosopher %d takes chopstick %d and%d\n",num+1,LEFT+1,num+1);
		printf("Philosopher %d is Eating\n",num+1);
}
}
void takeUp_chopstick(int num){

	sem_wait(&mutex);
	state[num]=HUNGRY;
	printf("Philosopher %d is Hungry\n",num+1);
	
	hungryEating(num);
	sem_post(&mutex);
	sem_wait(&P[num]);
}
void putDown_chopstick(int num){
	sem_wait(&mutex);
	state[num]=THINKING;
	printf("Philosopher %d putting chopstick %d and %d down\n",
		num+1,LEFT+1,num+1);
	printf("Philosopher %d is thinkinh\n",num+1);
	hungryEating(LEFT);
	hungryEating(RIGHT);
	sem_post(&mutex);
}
void* philosopher(void* num){
	while(1){
		int* i=num;
		
		takeUp_chopstick(*i);
	
		putDown_chopstick(*i);
	}
}

int main(){
	int i;
	pthread_t thread_id[PHILOSOPHER];
	sem_init(&mutex,0,1);
	for(i=0; i<PHILOSOPHER; i++){
		sem_init(&P[i],0,0);
	}
	for(i=0; i<PHILOSOPHER; i++);{
		pthread_create(&thread_id[i],NULL,philosopher,&phil[i]);
		printf("PHILOSOPHER %d is thinking\n",i+1);
	}
	
	for(i=0; i<PHILOSOPHER; i++){
		pthread_join(thread_id[i], NULL);
}
}